var rectW = 200; 

function game2Preload()
{
  
}

function game2Setup(){
    createCanvas(400, 400);
  background('black');
  currentActivity = 2;
  
  menuButton.show();
  game1Button.show();
  game2Button.hide();
  game3Button.show();
}

function game2Draw()
{
   
  createCanvas(400, 400);
  background('black');
  fill('white');
  circle(30,139,10);  
  circle(100,45,8);  
  circle(343,75,5);  
  circle(387,176,6); 
  circle(34,390,5); 
  circle(200,360,4); 
  circle(183,276,4); 
  circle(327,380,5); 
  circle(76,376,6);
  circle(235,38,4);
  fill('rgb(186,184,184)')
  circle(100,250,120);
  fill('grey')
  circle(100,220,40);
  fill('grey')
  circle(90,260,20);
  fill('grey')
  circle(120,280,30);
  
  
  

  noStroke();
  fill('green'); 
  rect(0, 0, rectW, height);
  
  
  

  textAlign(CENTER);
  textSize(40);
  fill(255);

  if (rectW == 400) {
    text("Galaxy is Saved!", width / 2, height / 2);
    textSize(20);
    text("Hit the R key to restart the game", width / 2, height / 2 + 60);
  }
  
  if (rectW == 0) {
    text("Galaxy is Saved!", width / 2, height / 2);
    textSize(20);
    text("Hit the R key to restart the game", width / 2, height / 2 + 60);
  }
  
  textSize(14);
       fill('white');
        textAlign(CENTER);
  
        text('Hit the "f" key to remove the alien green and save the galaxy!', 200,50);
        text('Fill the canvas with your color to win!',200, 70);

}

function keyPressed() {

  if (key == "q" && rectW > 0 && rectW < 400) {
    rectW += 10;
  }

  if (key == "f" && rectW > 0 && rectW < 400) {
    rectW -= 10;
  }

  if (key == "r") {
    rectW = 200;
  }

function game2MousePressed(){
  
}
}