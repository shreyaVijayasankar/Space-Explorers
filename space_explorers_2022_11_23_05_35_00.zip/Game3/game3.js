let exercise3x = 200;
let exercise3y = 200;
var screen = 0;
var y=-20;
var x=200;
var speed = 2;
var score= 0;

function game3Preload(){
  
}

function game3Setup(){
  background(220);
  currentActivity = 3;
  
  // Hide the Activity 3 button, show all the other buttons
  menuButton.show();
  game1Button.show();
  game2Button.show();
  game3Button.hide();
}

function game3Draw()
{
 if(screen == 0){
    startScreen()
  }else if(screen == 1){
  	gameOn()
  }else if(screen==2){
  	endScreen()
  }	
}


function startScreen(){
		background('black');
  
  fill('rgb(255,255,255)');
        circle(320, 200, 10);
        circle(390, 220, 4);
        circle(180, 109, 8);
        circle(350, 300, 10);
        circle(60,300 , 14);
        circle(90, 250, 10);
        circle(220, 370, 5);
  
       fill('rgb(26,147,197)');
        ellipse(100, 110, 220, 220);
        fill('rgb(8,66,90)');
        ellipse(100, 110, 280, 30);
        fill('#FFEB3B');
        ellipse(400, 40, 200, 200);
        fill('rgb(184,235,170)');
        ellipse(300, 300, 150, 150);

		textAlign(CENTER);
        textSize(16);
        fill(255)  
        fill('#CDDC39');
		text('*Star Catcher*', width / 2, height / 2)
        textSize(10);
        textAlign(CENTER);
        
  
		text('Click to start!', width / 2, height / 2 + 20);
		reset();
}

function gameOn(){
	background(0)
  textSize(14);
  fill('#FFEB3B');
        ellipse(400, 40, 200, 200);
  fill('rgb(255,130,130)');
  text("score = " + score, 195,90)
  
  fill('#2196F3');
  text("Move your cursor left and right", 190, 40) ;
  text("to catch the falling stars!",185,60);
  
  fill('white');
  ellipse(x,y,20,20)
  rectMode(CENTER)
  fill('grey');
  rect(mouseX,height-10,50,30)
	y+= speed;
  if(y>height){
  	screen =2
	 }
  if(y>height-10 && x>mouseX-20 && x<mouseX+20){
  	y=-20
    speed+=0.5
    score+= 1
  }
	if(y==-20){
  	pickRandom();
  }
}

function pickRandom(){
	x= random(20,width-20)
}

function endScreen(){
		background('black')
		textAlign(CENTER);
  	text("SCORE = " + score, width / 2, height / 2)
		text('Click to try again!', width / 2, height / 2 + 40);
}

function mousePressed()
{
	if(screen==0){
  	screen=1
  }else if(screen==2)
  {
  	screen=0
  }
}

function reset()
{
	  score=0;
  	speed=2;
  	y=-20;
}


