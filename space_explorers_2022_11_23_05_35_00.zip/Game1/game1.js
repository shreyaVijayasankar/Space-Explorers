var insectx = 300;
var insecty = 300; 
var insectSize = 40;
var score = 0;
var game = "Level 1";

function game1Preload(){
  
}

function game1Setup(){
  background('#fae');
  currentActivity = 1;
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.show();
  game3Button.show();
  
}

function game1Draw()
{
  background('#fae');
 
  createCanvas(400, 400);
    background('black');
  
  fill('white');
  circle(50,20,5);
  circle(170,200,7);
  circle(300,100,6);
  circle(350,210,5);
  circle(20,350,6);
  circle(360,350,5);
  circle(50,260,5);
  
  catchInsect();
  
  textSize(15);
  text(("Score: " + score), 200,45);
  
  fill('pink');
  text(("Catch the UFO!"),200,90);
}

function catchInsect() {
  var distance = dist(insectx,insecty,mouseX,mouseY)
  if (distance < insectSize / 2) {
    insectx = random(width);
    insecty = random(height);
    score++;
    fill('white');
    textSize(30);
    text('Nice!',160,200);
  }
  fill('gray')
  ellipse(insectx,insecty,insectSize,20);
}

