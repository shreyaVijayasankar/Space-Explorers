/****
 * FSE100: examples for how to link multiple exercises together
 *****/

let currentActivity = 0;
let menuButton, game1Button, game2Button, game3Button;

/***** 
  * If you want to load images or sounds into your application,
  * try using preload()
  * https://p5js.org/reference/#/p5/preload
  *****/
function preload(){
  game1Preload();
  game2Preload();
  game3Preload();
}

function switchToMM(){
  background(220);
  currentActivity = 0;
  
  // Hide the home page button, show the activity buttons
  menuButton.hide();
  game1Button.show();
  game2Button.show();
  game3Button.show();
}

function setup() {
  createCanvas(400, 400);
  
  menuButton = createButton('Home Page');
  menuButton.position(0, 0);
  menuButton.mousePressed(switchToMM);
  menuButton.hide();
  
  game1Button = createButton('Game 1');
  game1Button.position(10, 120);
  game1Button.mousePressed(game1Setup);
  game1Button.show();
  
  game2Button = createButton('Game 2');
  game2Button.position(10, 200);
  game2Button.mousePressed(game2Setup);
  game2Button.show();
  
  game3Button = createButton('Game 3');
  game3Button.position(10, 280);
  game3Button.mousePressed(game3Setup);
  game3Button.show();

}


function draw() { 
  switch(currentActivity){
    case 0: 
      mainMenu();
      break;
    case 1: 
      game1Draw();
      break;
    case 2: 
      game2Draw();
      break;
    case 3: 
      game3Draw();
      break;
  }
}

function mainMenu(){
  background(220);
  
  background('black');
   fill('rgb(255,255,255)');
        circle(320, 200, 10);
        circle(390, 220, 4);
        circle(180, 109, 8);
        circle(350, 300, 10);
        circle(60,300 , 14);
        circle(90, 250, 10);
        circle(220, 370, 5);
   fill('rgb(173,106,177)');
        ellipse(100, 110, 220, 220);
        fill('rgb(255,111,214)');
        ellipse(100, 110, 280, 20);
        fill('#FFEB3B');
        ellipse(400, 40, 200, 200);
        fill('rgb(124,0,16)');
        ellipse(300, 300, 150, 150);

        textSize(30);
        fill('white');
        textAlign(CENTER);
        text('Space Explorers!',200,50);
  
}

/*****
* mousePressed() is a reserved function that is called whenever
* the user presses the mouse button in the application.
*****/
function mousePressed(){
  // Only game 4 uses the mousePressed function, but the switch statement
  // makes it easy to add the mousePressed functionality for other games.
  switch(currentActivity){
    case 2: 
      game2MousePressed();
      break;
  }
}